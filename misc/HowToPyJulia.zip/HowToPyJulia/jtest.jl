function foo(x)
    if x > 0
        return x * 2 ,x*6
    else
        return x*3, x*4, x*5
    end
end